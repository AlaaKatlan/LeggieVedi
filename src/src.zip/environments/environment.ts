export const environment = {
  production: false,
  supabaseUrl: 'https://ysvghpcdhhpwelykrvdh.supabase.co',
  supabaseAnonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlzdmdocGNkaGhwd2VseWtydmRoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTgwNDQ4NzAsImV4cCI6MjA3MzYyMDg3MH0.vBjhZAqp0m300TrxC3xWe_xsqMx2RbuV8r9zlYHWfiQ'
};
