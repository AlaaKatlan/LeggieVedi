import { Component } from '@angular/core';

@Component({
  selector: 'app-artworks-manager',
  standalone: true,
  imports: [],
  templateUrl: './artworks-manager.component.html',
  styleUrl: './artworks-manager.component.scss'
})
export class ArtworksManagerComponent {

}
