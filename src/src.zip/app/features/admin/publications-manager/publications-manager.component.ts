import { Component } from '@angular/core';

@Component({
  selector: 'app-publications-manager',
  standalone: true,
  imports: [],
  templateUrl: './publications-manager.component.html',
  styleUrl: './publications-manager.component.scss'
})
export class PublicationsManagerComponent {

}
