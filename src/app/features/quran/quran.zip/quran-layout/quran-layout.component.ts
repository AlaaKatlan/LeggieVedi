import { ChangeDetectorRef, Component, computed, inject, Signal, signal, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { SurahListComponent } from '../surah-list/surah-list.component'; // تأكد من أن المسار صحيح
import { WordViewerComponent } from '../../../layout/components/word-viewer/word-viewer.component';

@Component({
  selector: 'app-quran-layout',
  standalone: true,
  imports: [CommonModule, RouterOutlet, SurahListComponent, WordViewerComponent],
  templateUrl: './quran-layout.component.html',
  styleUrls: ['./quran-layout.component.scss']
})
export class QuranLayoutComponent {
  isSidebarOpen = signal(false);

  @ViewChild(SurahListComponent) private surahList!: SurahListComponent;

  // ▼▼▼ هذا هو التصحيح الكامل للخطأ ▼▼▼
  // 3. قم بتهيئة الـ Signal مباشرة كـ computed
  //    سيقوم بمراقبة التغييرات بنفسه
  public wordFilePath: Signal<string | null> = computed(() => {
    // 4. أضف شرط أمان:
    //    قبل أن يتم تحميل الابن (surahList)، ستكون القيمة null
    //    بعد أن يتم تحميله، سيقرأ الـ signal الخاص بالابن
    if (this.surahList) {
      return this.surahList.wordFilePath();
    }
    return null; // القيمة الافتراضية هي null
  });
  // ▲▲▲ نهاية التصحيح ▲▲▲

  // 5. دالة الإغلاق
  public closeWordViewer() {
    // أضف شرط أمان هنا أيضاً
    if (this.surahList) {
      this.surahList.closeWord();
    }
  }
}
