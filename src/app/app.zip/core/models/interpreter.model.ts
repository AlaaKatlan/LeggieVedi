export interface Interpreter {
  id: number;
  short_name: string;
  display_name_it: string;
}
